
######################################################################################
                #   sample times, etc
######################################################################################
ts_simulation = 1/240.  # smallest time step for simulation
ts_simslow = 1/50.
start_time = 0.  # start time for simulation
end_time = 400.  # end time for simulation
viz_time = 0.5

ts_plot_refresh = 2  # seconds between each plot update
ts_plot_record_data = 1/60. # seconds between each time data is recorded for plots
ts_video = 0.1  # write rate for video
ts_videoslow = 1/50.
ts_control = ts_simulation  # sample rate for the controller


